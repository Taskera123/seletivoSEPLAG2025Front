import './App.css'
import AppRoutes from "./routes/AppRoutes";
import TopoInstitucional from './components/TopoInstitucional';

function App() {

  return <AppRoutes />;
}

export default App
